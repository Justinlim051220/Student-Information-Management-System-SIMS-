﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="StudentSidebar.ascx.cs" Inherits="Student_Information_Management_System__SIMS_.Student.StudentSidebar" %>

<div class="sidebar" id="sidebar">

    <div class="sidebar-brand">
        <img src="../Images/Logo_Dashboard.png" alt="ONTI SIMS" class="brand-logo" />
        <div class="brand-text">
            <div class="brand-name">SIMS</div>
            <div class="brand-sub">Student Portal</div>
        </div>
    </div>

    <nav class="sidebar-nav">
        <div class="sidebar-section-label">Main</div>

        <a href="Student_Dashboard.aspx" class="<%= NavClass("Student_Dashboard") %>">
            <i class="fa-solid fa-gauge-high nav-icon"></i> Dashboard
        </a>

        <div class="sidebar-section-label" style="margin-top:12px;">Academic</div>

        <a href="MyCourses.aspx" class="<%= NavClass("MyCourses") %>">
            <i class="fa-solid fa-book-open nav-icon"></i> My Courses
        </a>

        <a href="Attendance.aspx" class="<%= NavClass("Attendance") %>">
            <i class="fa-solid fa-calendar-check nav-icon"></i> Attendance
        </a>

        <a href="Student_Enrollment.aspx" class="<%= NavClass("Student_Enrollment") %>">
            <i class="fa-solid fa-clipboard-list nav-icon"></i> Enrollment
        </a>

        <a href="Results.aspx" class="<%= NavClass("Results") %>">
            <i class="fa-solid fa-chart-line nav-icon"></i> Results
        </a>

        <div class="sidebar-section-label" style="margin-top:12px;">Finance</div>

        <a href="Student_Payment.aspx" class="<%= NavClass("Student_Payment") %>">
            <i class="fa-solid fa-money-bill-wave nav-icon"></i> Payment
        </a>

        <div class="sidebar-section-label" style="margin-top:12px;">Communication</div>

        <a href="Notification.aspx" class="<%= NavClass("Notification") %>">
            <i class="fa-solid fa-bell nav-icon"></i> Notifications
            <asp:Panel ID="pnlSidebarNotifBadge"
                runat="server"
                CssClass="badge-dot dashboard-hidden-badge"
                Visible="false"
                Style="display:none !important;" />
        </a>

        <a href="Contacts.aspx" class="<%= NavClass("Contacts") %>">
            <i class="fa-solid fa-address-book nav-icon"></i> Contacts
        </a>

        <div class="sidebar-section-label" style="margin-top:12px;">Account</div>

        <a href="MyProfile.aspx" class="<%= NavClass("MyProfile") %>">
            <i class="fa-solid fa-circle-user nav-icon"></i> My Profile
        </a>
    </nav>

    <div class="sidebar-footer">
        <div class="sidebar-user">
            <div class="user-avatar">
                <asp:Label ID="lblAvatarInitial" runat="server" Text="S" />
            </div>

            <div class="user-info">
                <div class="user-name">
                    <asp:Label ID="lblSidebarName" runat="server" Text="Student" />
                </div>
                <div class="user-role">Student</div>
            </div>
        </div>

        <asp:LinkButton ID="lbLogout"
            runat="server"
            CssClass="sidebar-link"
            OnClientClick="showLogoutModal(); return false;">
            <i class="fa-solid fa-right-from-bracket"></i> Log Out
        </asp:LinkButton>
    </div>

</div>

<div id="logoutModal" class="modal-overlay system-dialog">
    <div class="modal-box">
        <div class="modal-head">
            <div class="logout-warning-icon">
                <i class="fa-solid fa-triangle-exclamation"></i>
            </div>
            <span>Log Out</span>
        </div>

        <div class="modal-body">
            Are you sure you want to log out?
        </div>

        <div class="modal-actions">
            <button type="button" class="modal-cancel" onclick="hideLogoutModal();">Cancel</button>

            <asp:LinkButton ID="btnConfirmLogout"
                runat="server"
                CssClass="modal-submit"
                OnClick="btnConfirmLogout_Click">
                Log Out
            </asp:LinkButton>
        </div>
    </div>
</div>