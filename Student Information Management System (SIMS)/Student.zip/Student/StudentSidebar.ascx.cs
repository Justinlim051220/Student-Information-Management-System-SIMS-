﻿using System;
using System.IO;
using System.Web.UI;
using SIMS.Helpers;

namespace Student_Information_Management_System__SIMS_.Student
{
    public partial class StudentSidebar : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadStudentInfo();
            }
        }

        public string NavClass(string pageName)
        {
            string currentPage = Path.GetFileNameWithoutExtension(Page.AppRelativeVirtualPath);

            return string.Equals(currentPage, pageName, StringComparison.OrdinalIgnoreCase)
                ? "sidebar-link active"
                : "sidebar-link";
        }

        private void LoadStudentInfo()
        {
            string fullName = SessionHelper.GetFullName(Session);

            lblSidebarName.Text = string.IsNullOrWhiteSpace(fullName)
                ? "Student"
                : fullName;

            lblAvatarInitial.Text = string.IsNullOrWhiteSpace(fullName)
                ? "S"
                : fullName[0].ToString().ToUpper();
        }

        protected void btnConfirmLogout_Click(object sender, EventArgs e)
        {
            SessionHelper.Logout(Session);
            Response.Redirect("~/Login.aspx", false);
        }
    }
}